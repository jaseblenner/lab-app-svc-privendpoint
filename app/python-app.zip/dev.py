import platform

from flask import Flask
from flask import request
from flask_restful import Resource, Api
import sys
import psutil
import time
import os
app = Flask(__name__)
api = Api(app)
port = 5100


if sys.argv.__len__() > 1:
    port = sys.argv[1]
print("Api running on port : {} ".format(port))

class topic_tags(Resource):
    def get(self):
        return "Test"

api.add_resource(topic_tags, '/')


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=port)

@app.route('/')
def hello_world():
    return 'Hello, This is a Python Flask example app deployed via Terraform on {}!'.format(platform.uname()[1])
    return 'Hello, This is a Python Flask example app deployed via Terraform on {}!'.format(platform.uname()[1])


@app.route('/health')
def healthcheck():
    return 'OK'


@app.route('/uptime')
def container_uptime():
    return "{}".format(time.time() - psutil.Process(os.getpid()).create_time())
